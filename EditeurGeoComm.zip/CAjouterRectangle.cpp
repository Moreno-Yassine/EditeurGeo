/*************************************************************************
                           CAjouterRectangle  -  description
                             -------------------
    début                : 13 janv. 2014
    copyright            : (C) 2014 par ymoreno
*************************************************************************/

//---------- Réalisation de la classe <CAjouterRectangle> (fichier CAjouterRectangle.cpp) -------

//---------------------------------------------------------------- INCLUDE

//-------------------------------------------------------- Include système
using namespace std;
#include <iostream>

//------------------------------------------------------ Include personnel
#include "CAjouterRectangle.h"

//------------------------------------------------------------- Constantes

//----------------------------------------------------------------- PUBLIC

//----------------------------------------------------- Méthodes publiques
// type CAjouterRectangle::Méthode ( liste des paramètres )
// Algorithme :
//
//{
//} //----- Fin de Méthode


//------------------------------------------------- Surcharge d'opérateurs
CAjouterRectangle & CAjouterRectangle::operator = ( const CAjouterRectangle & unCAjouterRectangle )
// Algorithme :
//
{
} //----- Fin de operator =


//-------------------------------------------- Constructeurs - destructeur
CAjouterRectangle::CAjouterRectangle ( const CAjouterRectangle & unCAjouterRectangle )
// Algorithme :
//
{
#ifdef MAP
    cout << "Appel au constructeur de copie de <CAjouterRectangle>" << endl;
#endif
} //----- Fin de CAjouterRectangle (constructeur de copie)


CAjouterRectangle::CAjouterRectangle ( )
// Algorithme :
//
{
#ifdef MAP
    cout << "Appel au constructeur de <CAjouterRectangle>" << endl;
#endif
} //----- Fin de CAjouterRectangle


CAjouterRectangle::~CAjouterRectangle ( )
// Algorithme :
//
{
#ifdef MAP
    cout << "Appel au destructeur de <CAjouterRectangle>" << endl;
#endif
} //----- Fin de ~CAjouterRectangle


//------------------------------------------------------------------ PRIVE

//----------------------------------------------------- Méthodes protégées

