/*************************************************************************
                           CAjouterPolyligne  -  description
                             -------------------
    début                : 13 janv. 2014
    copyright            : (C) 2014 par ymoreno
*************************************************************************/

//---------- Réalisation de la classe <CAjouterPolyligne> (fichier CAjouterPolyligne.cpp) -------

//---------------------------------------------------------------- INCLUDE

//-------------------------------------------------------- Include système
using namespace std;
#include <iostream>

//------------------------------------------------------ Include personnel
#include "CAjouterPolyligne.h"

//------------------------------------------------------------- Constantes

//----------------------------------------------------------------- PUBLIC

//----------------------------------------------------- Méthodes publiques
// type CAjouterPolyligne::Méthode ( liste des paramètres )
// Algorithme :
//
//{
//} //----- Fin de Méthode


//------------------------------------------------- Surcharge d'opérateurs
CAjouterPolyligne & CAjouterPolyligne::operator = ( const CAjouterPolyligne & unCAjouterPolyligne )
// Algorithme :
//
{
} //----- Fin de operator =


//-------------------------------------------- Constructeurs - destructeur
CAjouterPolyligne::CAjouterPolyligne ( const CAjouterPolyligne & unCAjouterPolyligne )
// Algorithme :
//
{
#ifdef MAP
    cout << "Appel au constructeur de copie de <CAjouterPolyligne>" << endl;
#endif
} //----- Fin de CAjouterPolyligne (constructeur de copie)


CAjouterPolyligne::CAjouterPolyligne ( )
// Algorithme :
//
{
#ifdef MAP
    cout << "Appel au constructeur de <CAjouterPolyligne>" << endl;
#endif
} //----- Fin de CAjouterPolyligne


CAjouterPolyligne::~CAjouterPolyligne ( )
// Algorithme :
//
{
#ifdef MAP
    cout << "Appel au destructeur de <CAjouterPolyligne>" << endl;
#endif
} //----- Fin de ~CAjouterPolyligne


//------------------------------------------------------------------ PRIVE

//----------------------------------------------------- Méthodes protégées

