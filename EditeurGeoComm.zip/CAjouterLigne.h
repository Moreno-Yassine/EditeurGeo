/*************************************************************************
                           CAjouterLigne  -  description
                             -------------------
    début                : 13 janv. 2014
    copyright            : (C) 2014 par ymoreno
*************************************************************************/

//---------- Interface de la classe <CAjouterLigne> (fichier CAjouterLigne.h) ------
#if ! defined ( CAJOUTERLIGNE_H_ )
#define CAJOUTERLIGNE_H_

//--------------------------------------------------- Interfaces utilisées

//------------------------------------------------------------- Constantes 

//------------------------------------------------------------------ Types 

//------------------------------------------------------------------------ 
// Rôle de la classe <CAjouterLigne>
//
//
//------------------------------------------------------------------------ 

class CAjouterLigne : public Ancetre
{
//----------------------------------------------------------------- PUBLIC

public:
//----------------------------------------------------- Méthodes publiques
    // type Méthode ( liste des paramètres );
    // Mode d'emploi :
    //
    // Contrat :
    //


//------------------------------------------------- Surcharge d'opérateurs
    CAjouterLigne & operator = ( const CAjouterLigne & unCAjouterLigne );
    // Mode d'emploi :
    //
    // Contrat :
    //


//-------------------------------------------- Constructeurs - destructeur
    CAjouterLigne ( const CAjouterLigne & unCAjouterLigne );
    // Mode d'emploi (constructeur de copie) :
    //
    // Contrat :
    //

    CAjouterLigne ( );
    // Mode d'emploi :
    //
    // Contrat :
    //

    virtual ~CAjouterLigne ( );
    // Mode d'emploi :
    //
    // Contrat :
    //

//------------------------------------------------------------------ PRIVE 

protected:
//----------------------------------------------------- Méthodes protégées

//----------------------------------------------------- Attributs protégés

};

//--------------------------- Autres définitions dépendantes de <CAjouterLigne>

#endif // CAJOUTERLIGNE_H_

