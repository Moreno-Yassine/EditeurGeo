/*************************************************************************
                           CAjouterLigne  -  description
                             -------------------
    début                : 13 janv. 2014
    copyright            : (C) 2014 par ymoreno
*************************************************************************/

//---------- Réalisation de la classe <CAjouterLigne> (fichier CAjouterLigne.cpp) -------

//---------------------------------------------------------------- INCLUDE

//-------------------------------------------------------- Include système
using namespace std;
#include <iostream>

//------------------------------------------------------ Include personnel
#include "CAjouterLigne.h"

//------------------------------------------------------------- Constantes

//----------------------------------------------------------------- PUBLIC

//----------------------------------------------------- Méthodes publiques
// type CAjouterLigne::Méthode ( liste des paramètres )
// Algorithme :
//
//{
//} //----- Fin de Méthode


//------------------------------------------------- Surcharge d'opérateurs
CAjouterLigne & CAjouterLigne::operator = ( const CAjouterLigne & unCAjouterLigne )
// Algorithme :
//
{
} //----- Fin de operator =


//-------------------------------------------- Constructeurs - destructeur
CAjouterLigne::CAjouterLigne ( const CAjouterLigne & unCAjouterLigne )
// Algorithme :
//
{
#ifdef MAP
    cout << "Appel au constructeur de copie de <CAjouterLigne>" << endl;
#endif
} //----- Fin de CAjouterLigne (constructeur de copie)


CAjouterLigne::CAjouterLigne ( )
// Algorithme :
//
{
#ifdef MAP
    cout << "Appel au constructeur de <CAjouterLigne>" << endl;
#endif
} //----- Fin de CAjouterLigne


CAjouterLigne::~CAjouterLigne ( )
// Algorithme :
//
{
#ifdef MAP
    cout << "Appel au destructeur de <CAjouterLigne>" << endl;
#endif
} //----- Fin de ~CAjouterLigne


//------------------------------------------------------------------ PRIVE

//----------------------------------------------------- Méthodes protégées

