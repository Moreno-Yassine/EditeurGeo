/*************************************************************************
                           CDelete  -  description
                             -------------------
    début                : 13 janv. 2014
    copyright            : (C) 2014 par ymoreno
*************************************************************************/

//---------- Interface de la classe <CDelete> (fichier CDelete.h) ------
#if ! defined ( CDELETE_H_ )
#define CDELETE_H_

//--------------------------------------------------- Interfaces utilisées

//------------------------------------------------------------- Constantes 

//------------------------------------------------------------------ Types 

//------------------------------------------------------------------------ 
// Rôle de la classe <CDelete>
//
//
//------------------------------------------------------------------------ 

class CDelete : public Ancetre
{
//----------------------------------------------------------------- PUBLIC

public:
//----------------------------------------------------- Méthodes publiques
    // type Méthode ( liste des paramètres );
    // Mode d'emploi :
    //
    // Contrat :
    //


//------------------------------------------------- Surcharge d'opérateurs
    CDelete & operator = ( const CDelete & unCDelete );
    // Mode d'emploi :
    //
    // Contrat :
    //


//-------------------------------------------- Constructeurs - destructeur
    CDelete ( const CDelete & unCDelete );
    // Mode d'emploi (constructeur de copie) :
    //
    // Contrat :
    //

    CDelete ( );
    // Mode d'emploi :
    //
    // Contrat :
    //

    virtual ~CDelete ( );
    // Mode d'emploi :
    //
    // Contrat :
    //

//------------------------------------------------------------------ PRIVE 

protected:
//----------------------------------------------------- Méthodes protégées

//----------------------------------------------------- Attributs protégés

};

//--------------------------- Autres définitions dépendantes de <CDelete>

#endif // CDELETE_H_

