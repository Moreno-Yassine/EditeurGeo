/*************************************************************************
                           CDelete  -  description
                             -------------------
    début                : 13 janv. 2014
    copyright            : (C) 2014 par ymoreno
*************************************************************************/

//---------- Réalisation de la classe <CDelete> (fichier CDelete.cpp) -------

//---------------------------------------------------------------- INCLUDE

//-------------------------------------------------------- Include système
using namespace std;
#include <iostream>

//------------------------------------------------------ Include personnel
#include "CDelete.h"

//------------------------------------------------------------- Constantes

//----------------------------------------------------------------- PUBLIC

//----------------------------------------------------- Méthodes publiques
// type CDelete::Méthode ( liste des paramètres )
// Algorithme :
//
//{
//} //----- Fin de Méthode


//------------------------------------------------- Surcharge d'opérateurs
CDelete & CDelete::operator = ( const CDelete & unCDelete )
// Algorithme :
//
{
} //----- Fin de operator =


//-------------------------------------------- Constructeurs - destructeur
CDelete::CDelete ( const CDelete & unCDelete )
// Algorithme :
//
{
#ifdef MAP
    cout << "Appel au constructeur de copie de <CDelete>" << endl;
#endif
} //----- Fin de CDelete (constructeur de copie)


CDelete::CDelete ( )
// Algorithme :
//
{
#ifdef MAP
    cout << "Appel au constructeur de <CDelete>" << endl;
#endif
} //----- Fin de CDelete


CDelete::~CDelete ( )
// Algorithme :
//
{
#ifdef MAP
    cout << "Appel au destructeur de <CDelete>" << endl;
#endif
} //----- Fin de ~CDelete


//------------------------------------------------------------------ PRIVE

//----------------------------------------------------- Méthodes protégées

