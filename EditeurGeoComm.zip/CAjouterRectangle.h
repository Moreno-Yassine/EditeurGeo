/*************************************************************************
                           CAjouterRectangle  -  description
                             -------------------
    début                : 13 janv. 2014
    copyright            : (C) 2014 par ymoreno
*************************************************************************/

//---------- Interface de la classe <CAjouterRectangle> (fichier CAjouterRectangle.h) ------
#if ! defined ( CAJOUTERRECTANGLE_H_ )
#define CAJOUTERRECTANGLE_H_

//--------------------------------------------------- Interfaces utilisées

//------------------------------------------------------------- Constantes 

//------------------------------------------------------------------ Types 

//------------------------------------------------------------------------ 
// Rôle de la classe <CAjouterRectangle>
//
//
//------------------------------------------------------------------------ 

class CAjouterRectangle : public Ancetre
{
//----------------------------------------------------------------- PUBLIC

public:
//----------------------------------------------------- Méthodes publiques
    // type Méthode ( liste des paramètres );
    // Mode d'emploi :
    //
    // Contrat :
    //


//------------------------------------------------- Surcharge d'opérateurs
    CAjouterRectangle & operator = ( const CAjouterRectangle & unCAjouterRectangle );
    // Mode d'emploi :
    //
    // Contrat :
    //


//-------------------------------------------- Constructeurs - destructeur
    CAjouterRectangle ( const CAjouterRectangle & unCAjouterRectangle );
    // Mode d'emploi (constructeur de copie) :
    //
    // Contrat :
    //

    CAjouterRectangle ( );
    // Mode d'emploi :
    //
    // Contrat :
    //

    virtual ~CAjouterRectangle ( );
    // Mode d'emploi :
    //
    // Contrat :
    //

//------------------------------------------------------------------ PRIVE 

protected:
//----------------------------------------------------- Méthodes protégées

//----------------------------------------------------- Attributs protégés

};

//--------------------------- Autres définitions dépendantes de <CAjouterRectangle>

#endif // CAJOUTERRECTANGLE_H_

